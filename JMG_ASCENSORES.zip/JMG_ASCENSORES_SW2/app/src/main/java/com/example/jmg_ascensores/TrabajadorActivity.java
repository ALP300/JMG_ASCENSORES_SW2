package com.example.jmg_ascensores;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class TrabajadorActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.vista_trabajador); // Cargar la vista del trabajador
    }

}
