package com.example.jmg_ascensores;

import java.util.Date;

public class EntAsc {

    private String model;
    private String marca;
    private Integer codAsc;

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public Integer getCodAsc() {
        return codAsc;
    }

    public void setCodAsc(Integer codAsc) {
        this.codAsc = codAsc;
    }
}

