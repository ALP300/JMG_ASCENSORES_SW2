package com.example.jmg_ascensores;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Tareas_empresa extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tareas_designadas);

    }
}
